<br />
<b>Warning</b>:  Undefined array key 6 in <b>/home/pierzen/public_html/hot/openlayers/nominatim/mapquestjs.php</b> on line <b>52</b><br />
<br />
<b>Warning</b>:  Undefined array key "q" in <b>/home/pierzen/public_html/hot/openlayers/nominatim/mapquestjs.php</b> on line <b>63</b><br />
<br />
<b>Warning</b>:  Undefined array key "limit" in <b>/home/pierzen/public_html/hot/openlayers/nominatim/mapquestjs.php</b> on line <b>64</b><br />
<br />
<b>Warning</b>:  Undefined array key "lang" in <b>/home/pierzen/public_html/hot/openlayers/nominatim/mapquestjs.php</b> on line <b>65</b><br />
<br />
<b>Warning</b>:  Undefined array key "HTTP_ACCEPT_LANGUAGE" in <b>/home/pierzen/public_html/hot/openlayers/nominatim/mapquestjs.php</b> on line <b>67</b><br />

/* end */
