<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width,initial-scale=1'>

  <title>Nominatim Demo</title>

  <link rel="icon" type="image/png" href="theme/favicon-194x194.png" sizes="194x194">
  <link rel="icon" type="image/png" href="theme/favicon-32x32.png" sizes="32x32">

  <link rel='stylesheet' href='build/bundle.css'>
  <link rel='stylesheet' href='theme/style.css'>

  <script src='config.defaults.js'></script>
  <script src='theme/config.theme.js'></script>

  <script>
    if (Nominatim_Config.Reverse_Only) {
      window.location.pathname = window.location.pathname.replace('search.html', 'reverse.html');
    }
  </script>
  <script defer src='build/bundle.js'></script>
</head>

<body>
</body>
</html>
